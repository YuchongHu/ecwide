#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include "libmemcached/memcached.h"

//gcc -std=c++11 test.cpp -o test -lmemcached

static double timeval_diff(struct timeval *start,
                           struct timeval *end)
{
    double r = end->tv_sec - start->tv_sec;
    if (end->tv_usec > start->tv_usec)
        r += (end->tv_usec - start->tv_usec) / 1000000.0;
    else if (end->tv_usec < start->tv_usec)
        r -= (start->tv_usec - end->tv_usec) / 1000000.0;
    return r;
}

int main(int argc, char *argv[])
{
    // //Commands
    // if (argc != 4)
    // {
    //     printf("Right Command: %s [key number] [key size] [value size]\n\n", argv[0]);
    //     exit(-1);
    // }
    int num_keys = 10;
    int key_size = 5;
    int value_size = 10;

    //printf("Num Keys: %d   Key size: %d  value size: %d\n", num_keys, key_size, value_size);

    //Initilize keys and values. Here let all keys equal ?�bar?� for simplicity.
    char **keys = (char **) malloc(num_keys * sizeof(char **));
    char **values = (char **) malloc(num_keys * sizeof(char **));
    for (int i = 0; i < num_keys ; i++)
    {
        keys[i] = (char *) malloc(key_size + 1);
        values[i] = (char *)malloc(value_size + 1);
        int j;
        for (j = 0 ; j < key_size ; j++)
        {
            keys[i][j] = (char) (rand() % 26 + 97);
        }
        keys[i][j] = 0;
        for(j = 0; j < value_size; j++)
        {
            values[i][j] = (char) (rand() % 26 + 97);
        }
        values[i][j] = 0;
    }

    //Add servers
    memcached_return rc;
    memcached_st *memc = memcached_create(NULL);
    memcached_server_st *servers = NULL;
    servers = memcached_server_list_append(servers, "127.0.0.1", 11211, &rc);
    servers = memcached_server_list_append(servers, "127.0.0.1", 11212, &rc);

    rc = memcached_server_push(memc, servers);
    if (rc == MEMCACHED_SUCCESS)
    {
        fprintf(stderr, "Added server successfully\n");
    }
    else
    {
        fprintf(stderr, "Couldn't add server: %s\n", memcached_strerror(memc, rc));
    }
    struct timeval start, end, diff;
    // gettimeofday(&start,0);
    //
    //Set keys and values
    for (int i = 0; i < num_keys ; i++)
    {
        memcached_set(memc, keys[i], strlen(keys[i]), values[i], strlen(values[i]), 0, 0);
    }
    //get values
    char *getval;
    size_t val_len;
    uint32_t flags;
    gettimeofday(&start, 0);
    for (int i = 0; i < num_keys ; i++)
    {
        getval = memcached_get(memc, keys[i], strlen(keys[i]), &val_len, &flags, &rc);
        printf("%d[%s]->{%s}\n", i, keys[i], getval);
        free(getval);
    }

    //delete values
    // gettimeofday(&start,0);
    //  for(int i=0;i<num_keys/4;i++)
    /* for(int i=0;i<4;i++)
     {
        memcached_delete(memc,keys[i],strlen(keys[i]),0);
     }*/
    gettimeofday(&end, 0);
    printf("\ntotal time is %f s\n", timeval_diff(&start,&end));

    //Get values from keys
    /* char *getval;
      size_t val_len;
      uint32_t flags;
      for (int i = 0; i < num_keys ; i++){
          getval = memcached_get(memc, keys[i], strlen(keys[i]), &val_len, &flags, &rc);
    printf("'key[%d]:%s'->'%s'\n",i, keys[i], getval);
          free(getval);
      }*/

    //Stop Memcached
    memcached_server_list_free(servers);
    memcached_free(memc);

    //Delete keys
    for (int i = 0; i < num_keys ; i++)
    {
        free(keys[i]);
        free(values[i]);
    }
    free(keys);
    free(values);
    return 0;
}
