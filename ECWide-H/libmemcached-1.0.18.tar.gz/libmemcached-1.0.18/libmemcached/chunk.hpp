#pragma once

//each proxy has 20 memcached
extern uint32_t CHUNK_ID_INC[MAX_NODE]; //20

void chunk_waiting_init(struct ECHash_st *ptr);

void chunk_waiting_destroy(struct ECHash_st *ptr);

struct chunk_waiting_st *chunk_waiting_push(struct ECHash_st *ptr, uint32_t index_tag);

struct chunk_waiting_st *chunk_waiting_pop(struct ECHash_st *ptr);

uint32_t chunk_waiting_set_kv(const char *key, uint32_t *chunk_id, struct ECHash_st *ptr, uint32_t index_tag, const char *value, size_t value_length);

void chunk_list_expand(struct ECHash_st *ptr, uint32_t index_tag);

void chunk_list_append_key(struct ECHash_st *ptr, uint32_t index_tag, uint32_t chunk_id, struct hash_node *hn);

//void chunk_list_set(struct ECHash_st *ptr, struct chunk_waiting_st *cws, uint32_t stripe_id);
