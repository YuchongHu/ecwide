#include "libmemcached/common.h"

uint32_t CHUNK_ID_INC[MAX_NODE] = {0};

extern int GROUP, RACK, NODE;

void chunk_waiting_init(struct ECHash_st *ptr)
{
    ptr->waiting_length = 0;
    ptr->sealing_chunk_num = 0;
    ptr->chunk_waiting_list = 0;
}

void chunk_waiting_destroy(struct ECHash_st *ptr)
{
    struct chunk_waiting_st *p = ptr->chunk_waiting_list, *q = p;
    while (p)
    {
        q = p->next;
        free(p->head);
        free(p);

        p = q;
    }
    ptr->waiting_length = 0;
    ptr->sealing_chunk_num = 0;
}

struct chunk_waiting_st *chunk_waiting_push(struct ECHash_st *ptr, uint32_t index_tag)
{
    struct chunk_waiting_st *cws = (struct chunk_waiting_st *)calloc(1,sizeof(struct chunk_waiting_st));

    //default=-1
    cws->index_tag = index_tag;

    //do not form the data chunk that chunkID % GROUP = gid;
    //this group for global parity
    //in the local group, there should be NODE -1
    //global group || local group && index
    // while ((CHUNK_ID_INC[index_tag] % GROUP == ptr->gid) || (CHUNK_ID_INC[index_tag] % RACK == ptr->rid) && CHUNK_ID_INC[index_tag] % NODE == index_tag) 
    // {
    //     CHUNK_ID_INC[index_tag]++;
    // }

    //consider local parity's position
    while(1)
    {
        if(CHUNK_ID_INC[index_tag] % GROUP == ptr->gid)
        {
            //printf("skip due to group\n");
            CHUNK_ID_INC[index_tag]++;
        }

        char key_local[100] = {0};
        sprintf(key_local, "local-%d-%d", ptr->gid, CHUNK_ID_INC[index_tag]);
        uint32_t index = memcached_generate_hash_with_redistribution(ptr->ring, key_local, strlen(key_local));
        if((CHUNK_ID_INC[index_tag] % RACK == ptr->rid) && (index == index_tag))
        {
            //printf("skip due to local parity\n");
            CHUNK_ID_INC[index_tag]++;
        }
        else
            break;
    }

    cws->chunk_id = CHUNK_ID_INC[index_tag]++;
    cws->KV_num = 0;
    cws->head = (char *)calloc(1, CHUNK_SIZE * sizeof(char));
    cws->current = cws->head;

    cws->chunk_used_size = 0;
    cws->can_sealing = 0;

    struct chunk_waiting_st *p = ptr->chunk_waiting_list;

    //tail insert
    if (p)
    {
        while (p->next)
        {
            p = p->next;
        }
        p->next = cws;
    }
    else //list is empty
    {
        ptr->chunk_waiting_list = cws;
    }
    cws->next = 0;

    ptr->waiting_length++;

    //printf("*[PUSH] index =%u, chunk_id=%u, into gid_self=%d, rid_self=%d, (GROUP,RACK)=(%d,%d) chunk_waiting_list\n", cws ->index_tag, cws->chunk_id, ptr->gid, ptr->rid, GROUP, RACK);

    return cws;
}


struct chunk_waiting_st *chunk_waiting_pop(struct ECHash_st *ptr)
{
    struct chunk_waiting_st *p = ptr->chunk_waiting_list, *q = p;
    //p is the first one,can sealing
    if (p->can_sealing == 1)
    {
        ptr->chunk_waiting_list = p->next;
    }
    else
    {
        while (p->can_sealing == 0)
        {
            q = p;
            p = p->next;
        }
        //p !=NULL;
        q->next = p->next;
    }

    //printf("*[POP] index_tag=%u, chunk_id=%u, used_size=%u, can_sealing=%u\n",p->index_tag, p->chunk_id, p->chunk_used_size, p->can_sealing);

    ptr->waiting_length--;
    ptr->sealing_chunk_num--;
    return p;
}

//-1, no sealed, index_tag
int check_chunk_sealed(struct ECHash_st *ptr, char *buffer, uint32_t *chunk_id)
{
    if (ptr->sealing_chunk_num == 0)
        return -1;
    else
    {
        struct chunk_waiting_st *p = chunk_waiting_pop(ptr);
        *chunk_id = p->chunk_id;
        int index_tag = p->index_tag;
        memcpy(buffer, p->head, CHUNK_SIZE);

        // printf("\n\n\np->head\n");
        // for(int i=0;i<4096;i++)
        // {
        //     printf("%c",(p->head)[i]);
        // }
        // printf("\n\n\n");

        //chunk_list
        ptr->chunk_list[index_tag][*chunk_id].stat = Sealed;
        ptr->chunk_list[index_tag][*chunk_id].used_size = p->chunk_used_size;
        ptr->chunk_list[index_tag][*chunk_id].KV_num = p->KV_num;

        free(p->head);
        free(p);
        return index_tag;
    }
}


//gather
char* gather(struct ECHash_st *ptr, uint32_t index_tag, uint32_t chunk_id)
{
    char *buffer=(char*)calloc(1,CHUNK_SIZE*sizeof(char));
    if(ptr->chunk_list[index_tag][chunk_id].stat != Sealed)
        printf("\n\nNOT SEALED\n\n");
    struct key_st *p = ptr->chunk_list[index_tag][chunk_id].key_list;
    size_t value_length;
    uint32_t  flags;
    memcached_return_t rc;

    while(p)
    {
        if(p->hn)
        {
            uint32_t pos = GET_POSITION(p->hn->value);
            uint32_t len = GET_LENGTH(p->hn->value);
            char *value=NULL;
            //int i=1;
            //printf("key[%s]=>(%u,%u)\n",p->hn->key,pos,len);
            value = memcached_get(ptr->ring, p->hn->key, strlen(p->hn->key), &value_length, &flags, &rc);
            // int i=0;
            // while(value == NULL)
            // {
            //     value = memcached_get(ptr->ring, p->hn->key, strlen(p->hn->key), &value_length, &flags, &rc);
            //     printf("re-get key{%s} %d times\n",p->hn->key,i++);
            // }

            //within rack, there is enough bandwidth
            if(value)
                memcpy(buffer+pos,value,value_length);
           else
            {
               printf("Get Miss (%s)\n",p->hn->key);
               memset(buffer+pos,0,len);
            }
        }

        p = p->next;
    }

    // printf("show chunk\n");
    // for(int i=0;i<CHUNK_SIZE;i++)
    // {
    //     printf("%c",buffer[i]);
    // }
    // printf("\n");

    // while(p)
    // {
    //     if(p->hn)
    //     {
    //         uint32_t pos = GET_POSITION(p->hn->value);
    //         uint32_t len = GET_LENGTH(p->hn->value);
            
    //         //may get fail
    //         char *value = memcached_get(ptr->ring, p->hn->key, strlen(p->hn->key), &value_length, &flags, &rc);
    //         static char a='A';
    //         if(value)
    //         {
    //             memset(buffer+pos,a,len);
    //             //memcpy(buffer+pos,value,len);
    //         }
    //         else
    //             memset(buffer+pos,a,len); //trival

    //         a=(a++)%('Z'-'A')+'A';
    //     }

    //     p = p->next;
    // }

    return buffer;
}


uint32_t chunk_waiting_set_kv(const char *key, uint32_t *chunk_id, struct ECHash_st *ptr, uint32_t index_tag, const char *value, size_t value_length)
{
    struct chunk_waiting_st *p = ptr->chunk_waiting_list;

    //for same server
    while (p)
    {
        if (p->index_tag == index_tag && CHUNK_SIZE - p->chunk_used_size >= value_length)
            break;
        p = p->next;
    }

    // //for normal
    // while(p)
    // {
    //     if(CHUNK_SIZE - p->chunk_used_size >= value_length)
    //         break;
    //     p = p->next;
    // }

    if (p)
    {
        //printf("\t[OLD]");
        memcpy(p->current, value, value_length);

        uint32_t pos = abs(p->current - p->head);
        p->current = p->current + value_length;
        p->chunk_used_size = p->chunk_used_size + value_length;
        p->KV_num++;

        //printf("Key[%s],index_tag=%u,chunk=%u,waiting=%u,sealing=%u,KV=%u,pos=%u,len=%zu, used=%u\n", \
               key, p->index_tag, p->chunk_id, ptr->waiting_length, ptr->sealing_chunk_num, p->KV_num, pos, value_length, p->chunk_used_size);
        if (1.0 * p->chunk_used_size / CHUNK_SIZE >= CHUNK_SEALED_FACTOR)
        {
            if (p->can_sealing == 0)
            {
                p->can_sealing = 1;
                ptr->sealing_chunk_num++;
            }
            //printf("Index_tag=%u,chunk=%u can sealing with factor=%f,now waiting=%u,sealing=%u\n", \
                   p->index_tag, p->chunk_id, 1.0 * p->chunk_used_size / CHUNK_SIZE, ptr->waiting_length, ptr->sealing_chunk_num);
        }

        *chunk_id = p->chunk_id;
        return pos;
    }
    else //push a new chunk
    {
        struct chunk_waiting_st *q = chunk_waiting_push(ptr, index_tag);
       // printf("\t[NEW]");
        memcpy(q->current, value, value_length);
        uint32_t pos = q->current - q->head;

        q->current = q->current + value_length;
        q->chunk_used_size = q->chunk_used_size + value_length;
        q->KV_num++;

        //printf("Key[%s],index_tag=%u,chunk=%u,waiting=%u,sealing=%u,KV=%u,pos=%u,len=%zu,used=%u\n", \
               key, q->index_tag, q->chunk_id, ptr->waiting_length, ptr->sealing_chunk_num, q->KV_num, pos, value_length, q->chunk_used_size);

        if (1.0 * q->chunk_used_size / CHUNK_SIZE >= CHUNK_SEALED_FACTOR)
        {
            if (q->can_sealing == 0)
            {
                q->can_sealing = 1;
                ptr->sealing_chunk_num++;
            }

            //printf("Index_tag=%u,chunk=%u can sealing with factor=%f,now waiting=%u,sealing=%u\n", \
                   q->index_tag, q->chunk_id, 1.0 * q->chunk_used_size / CHUNK_SIZE, ptr->waiting_length, ptr->sealing_chunk_num);
        }

        *chunk_id = q->chunk_id;

        return pos;
    }
}

void chunk_list_expand(struct ECHash_st *ptr, uint32_t index_tag)
{
    ptr->chunk_list_size[index_tag] = ptr->chunk_list_size[index_tag] * 2;
    ptr->chunk_list[index_tag] = (struct chunk_st *)realloc(ptr->chunk_list[index_tag], ptr->chunk_list_size[index_tag] * sizeof(struct chunk_st));
    if (ptr->chunk_list[index_tag] == NULL)
    {
        printf("\nMemory is out at chunk_list[%u] appending.\n",index_tag);
        exit(-1);
    }
    printf("\n Expand chunk_list[%u] from %u to %u\n", index_tag, ptr->chunk_list_size[index_tag] / 2, ptr->chunk_list_size[index_tag]);
}

void chunk_list_append_key(struct ECHash_st *ptr, uint32_t index_tag, uint32_t chunk_id, struct hash_node *hn)
{
    struct key_st *ks = (struct key_st *)malloc(sizeof(struct key_st));
    ks->hn = hn;
    ks->next = 0;

    //double
    if (chunk_id >= ptr->chunk_list_size[index_tag])
        chunk_list_expand(ptr, index_tag);

    struct key_st *p = ptr->chunk_list[index_tag][chunk_id].key_list;
    if (p)
    {
        while (p->next)
        {
            p = p->next;
        }
        p->next = ks;
    }
    else
    {
        ptr->chunk_list[index_tag][chunk_id].key_list = ks;
    }
}
