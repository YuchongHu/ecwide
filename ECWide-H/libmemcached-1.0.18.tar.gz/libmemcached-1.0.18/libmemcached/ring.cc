#include <libmemcached/common.h>
#include "../libhashkit/common.h"
#include <sys/stat.h>
#include <math.h>

uint32_t get_once;
uint32_t dget;
uint32_t dget_success;
uint32_t dget_failed;
uint32_t dget_not_encode;

double time_count_get = 0;
double time_count_dget = 0;
double time_parity_decode = 0;
double time_data_decode = 0;
double time_data_gather = 0;

uint32_t KV_data_all = 0;
uint32_t KV_parity_all = 0;
uint32_t KV_data_server_load[100] = {0};

int GROUP;
int RACK;
int NODE;

memcached_return_t ECHash_init(struct ECHash_st **ptr, int g, int r, int n, int gid, int rid)
{
    GROUP = g;
    RACK = r;
    NODE = n;

    (*ptr) = (struct ECHash_st *)malloc(sizeof(struct ECHash_st)); //create the struct ECHash_st

    (*ptr)->gid = gid;
    (*ptr)->rid = rid;

    (*ptr)->ring = memcached_create(NULL);
    memcached_behavior_set((*ptr)->ring, MEMCACHED_BEHAVIOR_DISTRIBUTION, MEMCACHED_DISTRIBUTION_CONSISTENT_KETAMA);
    (*ptr)->value_size = 0;
    chunk_waiting_init(*ptr);

    for(int i=0;i<NODE;i++)
    {
        ((*ptr)->chunk_list_size)[i] = CHUNK_LIST_INIT;
        ((*ptr)->chunk_list)[i] = (struct chunk_st *)calloc(CHUNK_LIST_INIT, sizeof(struct chunk_st));
    }


    hash_table_init((*ptr)->hash_table);

    printf("Rings init success.\n");
    return MEMCACHED_SUCCESS;
}

memcached_return_t ECHash_destroy(struct ECHash_st *ptr)
{
    memcached_free(ptr->ring);
    chunk_waiting_destroy(ptr);

    for(int i=0;i<NODE;i++)
    {
        for(int j=0;j < ptr ->chunk_list_size[i];j++)
        {
            struct chunk_st p = ptr->chunk_list[i][j];
            struct key_st *q = p.key_list, *k = q;
            while (q)
            {
                k = q;
                q = q->next;
                free(k);
            }
        }
        free(ptr->chunk_list[i]);
    }


    hash_table_destory(ptr->hash_table);

    //destroy_encode_st(ptr);

    printf("Rings had been destroyed.\n");
    return MEMCACHED_SUCCESS;
}

memcached_return_t ECHash_init_addserver(struct ECHash_st *ptr,
                                         const char *hostname, in_port_t port)
{
    memcached_return_t rc;
    rc = memcached_server_add(ptr->ring, hostname, port);

    return rc;
}

memcached_return_t ECHash_set(struct ECHash_st *ptr, const char *key, size_t key_length,
                              const char *value, size_t value_length,
                              time_t expiration,
                              uint32_t flags)
{
    memcached_return_t rc;

    KV_data_all++;

    // char v[20];
    // memset(v,'a',20);
    // value_length=20;

    rc = memcached_set(ptr->ring, key, key_length, value, value_length, expiration, flags);
    uint32_t server_key = memcached_generate_hash_with_redistribution(ptr->ring, key, key_length);
    KV_data_server_load[server_key]++;
    if (rc == MEMCACHED_SUCCESS)
    {
        ptr->value_size += value_length;

        uint32_t chunk_id;
        //*set into chunk_waiting_list
        uint32_t position = chunk_waiting_set_kv(key, &chunk_id, ptr, server_key, value, value_length);
        //construct hash_node
        uint64_t hash_value = create_value((uint64_t)server_key, (uint64_t)chunk_id, (uint64_t)position, (uint64_t)value_length);
        struct hash_node *hn = hash_node_init(key, hash_value);
        insert_hash_table_key(ptr->hash_table, hn, key);
        //set into the chunk_list
        chunk_list_append_key(ptr, server_key, chunk_id, hn);
    }
    else
    {
        printf("SET KV[%s] ERROR.\n", key);
        return rc;
    }

    return rc;
}

char *ECHash_get(struct ECHash_st *ptr, const char *key, size_t key_length,
                 size_t *value_length,
                 uint32_t *flags,
                 memcached_return_t *error)
{

    struct timeval begin, end;
    gettimeofday(&begin, NULL);
    char *value = memcached_get(ptr->ring, key, key_length, value_length, flags, error);
    gettimeofday(&end, NULL);

    time_count_get = time_count_get + (end.tv_sec - begin.tv_sec) + (double)(end.tv_usec - begin.tv_usec) / 1000000;

    if (value)
    {
        get_once++;
        return value;
    }
    else
    {
        // dget++;
        // gettimeofday(&begin, NULL);

        // int f1 = 0;
        // struct pos_len_st pos_len_list[1] = {0};
        // uint64_t hv = get_value_hash_table(ptr->rings[ring_id].hash_table, key);
        // // uint32_t chunk_id = GET_CHUNK_ID(hv);
        // pos_len_list[0].pos = GET_POSITION(hv);
        // pos_len_list[0].len = GET_LENGTH(hv);

        // value = ECHash_dget_data(ptr, key, key_length, error, &f1, pos_len_list, 1);

        // if(f1 == 0)
        // {
        //     dget_success++;
        // }
        // else if(f1 == -1)
        // {
        //     dget_failed++;
        // }
        // else if(f1 == 2)
        // {
        //     dget_not_encode++;
        // }
        // else
        // {
        //     printf("not consider?\n");
        // }

        // if(value)
        //     *value_length = strlen(value);
        // else
        //     *value_length = 0;
        // gettimeofday(&end, NULL);
        // time_count_dget = time_count_dget + (end.tv_sec - begin.tv_sec) + (double)(end.tv_usec - begin.tv_usec) / 1000000;
        return value;
    }
}
